// ====================================
// S10 PORTAL - NAVIGATION + LINKS + LOGOUT
// ====================================

// PAGE SWITCH
// ==============================

function showPage(
    page,
    element
) {

    const pages = [

        "homePage",
        "employeePage",
        "reportPage",
        "linksPage",
        "WebsitePage",
        "depositPage",
        "SOPPage",
        "SportsPage",
        "OtherPage"

    ];


    pages.forEach(id => {

        const el =
            document.getElementById(id);

        if (el) {

            el.style.display = "none";

        }

    });


    document
        .querySelectorAll(".menu-item")
        .forEach(item => {

            item.classList.remove(
                "active"
            );

        });


    const target =
        document.getElementById(
            page + "Page"
        );

    if (target) {

        target.style.display = "block";

    }


    if (page === "report") {

        loadMonthFilter();

        renderAllMistakes();

    }


    if (element) {

        element.classList.add(
            "active"
        );

    }

}


// ==============================
// CURRENT MONTH
// ==============================

function getRunningMonth() {

    const now =
        new Date();

    return now.toLocaleString(
        "default",
        {
            month: "long",
            year: "numeric"
        }
    );

}


// LINKS
// ==============================

function renderLinks(
    category,
    containerId
) {

    const container =
        document.getElementById(
            containerId
        );

    if (!container) return;


    container.innerHTML = "";


    allLinks

        .filter(item => {

            return (

                item.Category ===
                category &&

                String(
                    item.Active
                ).toUpperCase() ===
                "TRUE"

            );

        })

        .forEach(item => {

            container.innerHTML += `

                <div
                    class="
                        link-card
                        ${item.Color || ""}
                    "
                >

                    <a
                        href="${item.URL}"
                        target="_blank"
                    >
                        ${
                            item.Name ||
                            "-"
                        }
                    </a>

                </div>

            `;

        });

}


// ==============================
// LOGOUT
// ==============================

function logout() {

    const confirmLogout =
        confirm(
            "Are you sure you want to logout?"
        );


    if (confirmLogout) {

        localStorage.removeItem(
            "user"
        );

        localStorage.removeItem(
            "loginDate"
        );

        window.location.replace(
            "login.html"
        );

    }

}


// ==============================
// OPEN REPORT PAGE
// ==============================

function openReportPage() {

    const page =
        document.getElementById(
            "reportPage"
        );


    if (page) {

        page.style.display =
            "block";

        loadMonthFilter();

        renderAllMistakes();

    }

}




// ==============================
// MOBILE MENU
// ==============================

function toggleMenu() {

    const sidebar =
        document.querySelector(".sidebar");

    if (sidebar) {
        sidebar.classList.toggle("show");
    }

}
