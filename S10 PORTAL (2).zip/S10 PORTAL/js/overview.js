// ====================================
// S10 PORTAL - MISTAKE OVERVIEW
// ====================================

// ============================================================
// MISTAKE OVERVIEW
// ============================================================


// ==============================
// OVERVIEW CS FILTER
// ==============================

function loadOverviewCSFilter() {

    const select =
        document.getElementById(
            "overviewCSFilter"
        );


    if (!select) return;


    if (
        !Array.isArray(allData) ||
        allData.length === 0
    ) {

        return;

    }


    const currentValue =
        select.value ||
        "all";


    const names = [

        ...new Set(

            allData
                .map(item =>
                    String(
                        item["CS Name"] ||
                        ""
                    ).trim()
                )
                .filter(
                    name =>
                        name !== ""
                )

        )

    ].sort(
        (a, b) =>
            a.localeCompare(b)
    );


    select.innerHTML = `

        <option value="all">
            All CS
        </option>

    `;


    names.forEach(name => {

        const option =
            document.createElement(
                "option"
            );


        option.value =
            name;


        option.textContent =
            name;


        select.appendChild(
            option
        );

    });


    if (
        currentValue !== "all" &&
        names.includes(
            currentValue
        )
    ) {

        select.value =
            currentValue;

    }

}


// ============================================================
// IMPORTANT NEW YEAR / SECTION FILTER
// ============================================================


// ==============================
// OVERVIEW YEAR FILTER
// ==============================

function loadOverviewYearFilter() {

    const select =
        document.getElementById(
            "overviewYearFilter"
        );


    if (!select) return;


    const currentValue =
        select.value ||
        "2026-full";


    select.innerHTML = `

        <option value="2026-full">
            2026 Full Year
        </option>

        <option value="2026-1st">
            2026 1st Section
        </option>

        <option value="2026-2nd">
            2026 2nd Section
        </option>

    `;


    if (

        currentValue ===
            "2026-full" ||

        currentValue ===
            "2026-1st" ||

        currentValue ===
            "2026-2nd"

    ) {

        select.value =
            currentValue;

    }

    else {

        select.value =
            "2026-full";

    }

}


// ==============================
// GET SELECTED YEAR SECTION
// ==============================

function getOverviewYearSection() {

    const value =
        document.getElementById(
            "overviewYearFilter"
        )?.value ||
        "2026-full";


    // ==============================
    // 1ST SECTION
    // January - June
    // ==============================

    if (
        value ===
        "2026-1st"
    ) {

        return {

            value,

            year: 2026,

            startMonth: 0,

            endMonth: 5,

            label:
                "2026 1st Section"

        };

    }


    // ==============================
    // 2ND SECTION
    // July - December
    // ==============================

    if (
        value ===
        "2026-2nd"
    ) {

        return {

            value,

            year: 2026,

            startMonth: 6,

            endMonth: 11,

            label:
                "2026 2nd Section"

        };

    }


    // ==============================
    // FULL YEAR
    // January - December
    // ==============================

    return {

        value:
            "2026-full",

        year: 2026,

        startMonth: 0,

        endMonth: 11,

        label:
            "2026 Full Year"

    };

}


// ==============================
// OVERVIEW MONTH FILTER
// ==============================

function loadOverviewMonthFilter() {

    const select =
        document.getElementById(
            "overviewMonthFilter"
        );


    if (!select) return;


    const section =
        getOverviewYearSection();


    const currentValue =
        select.value ||
        "all";


    select.innerHTML = `

        <option value="all">
            All Months
        </option>

    `;


    for (

        let i =
            section.startMonth;

        i <=
            section.endMonth;

        i++

    ) {

        const option =
            document.createElement(
                "option"
            );


        option.value =
            String(i);


        option.textContent =
            mistakeMonthNames[i];


        select.appendChild(
            option
        );

    }


    const currentNumber =
        Number(currentValue);


    if (

        currentValue !==
            "all" &&

        Number.isInteger(
            currentNumber
        ) &&

        currentNumber >=
            section.startMonth &&

        currentNumber <=
            section.endMonth

    ) {

        select.value =
            currentValue;

    }

    else {

        select.value =
            "all";

    }

}


// ==============================
// GET OVERVIEW MISTAKES
// ==============================

function getOverviewMistakes() {

    if (!Array.isArray(allData)) {
        return [];
    }

    const csFilter =
        document.getElementById("overviewCSFilter")?.value || "all";

    const monthFilter =
        document.getElementById("overviewMonthFilter")?.value || "all";

    const section = getOverviewYearSection();

    const selectedMonth =
        monthFilter === "all"
            ? null
            : Number(monthFilter);

    return allData.filter(item => {

        const parts = getMistakeDateParts(item["Date"]);

        if (!parts) {
            return false;
        }

        // Compare integer calendar parts only.
        // No timezone conversion is involved here.
        if (parts.year !== section.year) {
            return false;
        }

        if (
            parts.month < section.startMonth ||
            parts.month > section.endMonth
        ) {
            return false;
        }

        if (
            selectedMonth !== null &&
            parts.month !== selectedMonth
        ) {
            return false;
        }

        if (csFilter !== "all") {

            const itemCS = String(
                item["CS Name"] || ""
            ).trim().toLowerCase();

            if (
                itemCS !==
                csFilter.trim().toLowerCase()
            ) {
                return false;
            }
        }

        return true;
    });
}


// ==============================
// RENDER OVERVIEW
// ==============================

function renderMistakeOverview() {

    const data =
        getOverviewMistakes();


    const total =
        data.length;


    const counted =
        data.filter(
            item =>
                getMistakeCountedStatus(
                    item
                )
        ).length;


    const notCounted =
        total -
        counted;


    const totalElement =
        document.getElementById(
            "overviewTotal"
        );


    const countedElement =
        document.getElementById(
            "overviewCounted"
        );


    const notCountedElement =
        document.getElementById(
            "overviewNotCounted"
        );


    const ratingElement =
        document.getElementById(
            "overviewRating"
        );


    if (totalElement) {

        totalElement.textContent =
            total;

    }


    if (countedElement) {

        countedElement.textContent =
            counted;

    }


    if (notCountedElement) {

        notCountedElement.textContent =
            notCounted;

    }


    if (ratingElement) {

        ratingElement.textContent =
            getMistakeRating(
                counted
            ).text;

    }


    const status =
        document.getElementById(
            "overviewChartStatus"
        );


    const cs =
        document.getElementById(
            "overviewCSFilter"
        )?.value ||
        "all";


    const month =
        document.getElementById(
            "overviewMonthFilter"
        )?.value ||
        "all";


    const section =
        getOverviewYearSection();


    const monthText =

        month === "all"

            ?

            "All Months"

            :

            mistakeMonthNames[
                Number(month)
            ];


    if (status) {

        status.textContent =

            `${
                cs === "all"
                    ? "All CS"
                    : cs
            } • ${
                section.label
            } • ${
                monthText
            }`;

    }


    // ==============================
    // CHART
    // ==============================

    renderMistakeOverviewChart(
        data,
        cs,
        month
    );


    // ==============================
    // SUBJECT BREAKDOWN
    // ==============================

    renderMistakeSubjectBreakdown(
        data
    );

}


// ==============================
// OVERVIEW CHART
// ==============================

function renderMistakeOverviewChart(
    data,
    selectedCS,
    selectedMonth
) {

    const canvas =
        document.getElementById("mistakeOverviewChart");

    if (!canvas) return;

    const ctx = canvas.getContext("2d");

    if (mistakeOverviewChart) {
        mistakeOverviewChart.destroy();
        mistakeOverviewChart = null;
    }

    let labels = [];
    let totalData = [];
    let countedData = [];
    let notCountedData = [];

    const section = getOverviewYearSection();

    /*
     * IMPORTANT DATE FIX
     * -------------------
     * getOverviewMistakes() has already applied the selected
     * year / section / month filter. The chart must NOT parse
     * the Date field again because a second Date conversion can
     * move a boundary date between months.
     *
     * From this point onward the chart works ONLY with the
     * already-filtered `data` array.
     */

    const chartData = Array.isArray(data)
        ? data.slice()
        : [];

    // ========================================================
    // SELECTED CS
    // ========================================================

    if (selectedCS !== "all") {

        // ====================================================
        // SELECTED CS + ALL MONTHS
        // ====================================================

        if (selectedMonth === "all") {

            const overviewMonths =
                mistakeMonthNames.slice(
                    section.startMonth,
                    section.endMonth + 1
                );

            labels = overviewMonths;

            totalData = overviewMonths.map(
                (_, index) => {

                    const monthIndex =
                        section.startMonth + index;

                    return chartData.filter(item => {

                        const parts =
                            getMistakeDateParts(
                                item["Date"]
                            );

                        if (!parts) return false;

                        return (
                            parts.year === section.year &&
                            parts.month === monthIndex
                        );

                    }).length;
                }
            );

            countedData = overviewMonths.map(
                (_, index) => {

                    const monthIndex =
                        section.startMonth + index;

                    return chartData.filter(item => {

                        const parts =
                            getMistakeDateParts(
                                item["Date"]
                            );

                        if (!parts) return false;

                        return (
                            parts.year === section.year &&
                            parts.month === monthIndex &&
                            getMistakeCountedStatus(item)
                        );

                    }).length;
                }
            );

            notCountedData = totalData.map(
                (value, index) =>
                    Math.max(
                        value - countedData[index],
                        0
                    )
            );
        }

        // ====================================================
        // SELECTED CS + SELECTED MONTH
        // ====================================================

        else {

            const subjects = {};

            chartData.forEach(item => {

                const subject = getMistakeSubject(item);

                subjects[subject] =
                    (subjects[subject] || 0) + 1;
            });

            const sorted = Object.entries(subjects).sort(
                (a, b) => b[1] - a[1]
            );

            labels = sorted.map(item => item[0]);

            totalData = sorted.map(item => item[1]);

            countedData = labels.map(subject =>
                chartData.filter(item =>
                    getMistakeSubject(item) === subject &&
                    getMistakeCountedStatus(item)
                ).length
            );

            notCountedData = totalData.map(
                (value, index) =>
                    Math.max(
                        value - countedData[index],
                        0
                    )
            );
        }
    }

    // ========================================================
    // ALL CS
    // ========================================================

    else {

        // ====================================================
        // ALL CS + ALL MONTHS
        // ====================================================

        if (selectedMonth === "all") {

            const csData = {};

            chartData.forEach(item => {

                const name = String(
                    item["CS Name"] || "Unknown"
                ).trim();

                if (!csData[name]) {
                    csData[name] = {
                        total: 0,
                        counted: 0,
                        notCounted: 0
                    };
                }

                csData[name].total++;

                if (getMistakeCountedStatus(item)) {
                    csData[name].counted++;
                } else {
                    csData[name].notCounted++;
                }
            });

            const sorted = Object.entries(csData).sort(
                (a, b) => b[1].total - a[1].total
            );

            labels = sorted.map(item => item[0]);

            totalData = sorted.map(item => item[1].total);

            countedData = sorted.map(item => item[1].counted);

            notCountedData = sorted.map(item => item[1].notCounted);
        }

        // ====================================================
        // ALL CS + SELECTED MONTH
        // ====================================================

        else {

            const csData = {};

            chartData.forEach(item => {

                const csName = String(
                    item["CS Name"] || "Unknown"
                ).trim();

                if (!csData[csName]) {
                    csData[csName] = {
                        total: 0,
                        counted: 0,
                        notCounted: 0
                    };
                }

                csData[csName].total++;

                if (getMistakeCountedStatus(item)) {
                    csData[csName].counted++;
                } else {
                    csData[csName].notCounted++;
                }
            });

            const sorted = Object.entries(csData).sort(
                (a, b) => b[1].total - a[1].total
            );

            labels = sorted.map(item => item[0]);

            totalData = sorted.map(item => item[1].total);

            countedData = sorted.map(item => item[1].counted);

            notCountedData = sorted.map(item => item[1].notCounted);
        }
    }


    // ==============================
    // CHART.JS CHECK
    // ==============================

    if (
        typeof Chart ===
        "undefined"
    ) {

        console.error(
            "Chart.js is not loaded."
        );

        return;

    }


    // ==============================
    // CREATE CHART
    // ==============================

    mistakeOverviewChart =

        new Chart(
            ctx,
            {

                type: "bar",


                data: {

                    labels: labels,


                    datasets: [

                        {

                            label:
                                "Total",

                            data:
                                totalData,

                            borderWidth:
                                1

                        }
]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,


                    interaction: {

                        mode:
                            "index",

                        intersect:
                            false

                    },


                    plugins: {

                        legend: {

                            display:
                                true

                        }

                    },


                    scales: {

                        y: {

                            beginAtZero:
                                true,

                            ticks: {

                                precision:
                                    0

                            }

                        }

                    }

                }

            }

        );

}


// ==============================
// OVERVIEW INIT
// ==============================

function initMistakeOverview() {

    loadOverviewCSFilter();

    loadOverviewYearFilter();

    loadOverviewMonthFilter();


    const csFilter =
        document.getElementById(
            "overviewCSFilter"
        );


    const yearFilter =
        document.getElementById(
            "overviewYearFilter"
        );


    const monthFilter =
        document.getElementById(
            "overviewMonthFilter"
        );


    // ==============================
    // CS CHANGE
    // ==============================

    if (csFilter) {

        csFilter.onchange =
            () => {

                renderMistakeOverview();

            };

    }


    // ==============================
    // YEAR / SECTION CHANGE
    // ==============================

    if (yearFilter) {

        yearFilter.onchange =
            () => {

                /*
                 * Important:
                 * When the section changes,
                 * the Month dropdown is rebuilt.
                 */

                loadOverviewMonthFilter();

                renderMistakeOverview();

            };

    }


    // ==============================
    // MONTH CHANGE
    // ==============================

    if (monthFilter) {

        monthFilter.onchange =
            () => {

                renderMistakeOverview();

            };

    }


    renderMistakeOverview();

}


// ==============================
// INIT OVERVIEW
// ==============================



// ============================================================
// SUBJECT BREAKDOWN
// ============================================================

function renderMistakeSubjectBreakdown(
    data
) {

    const container =
        document.getElementById(
            "mistakeSubjectBreakdown"
        );


    if (!container) return;


    if (
        !Array.isArray(data) ||
        !data.length
    ) {

        container.innerHTML = `

            <div
                class="
                    subject-breakdown-empty
                "
            >
                No mistake data available
            </div>

        `;

        return;

    }


    const subjects = {};


    data.forEach(
        item => {

            const subject =
                getMistakeSubject(
                    item
                );


            if (
                !subjects[subject]
            ) {

                subjects[
                    subject
                ] = {

                    total: 0,

                    counted: 0,

                    notCounted: 0

                };

            }


            subjects[
                subject
            ].total++;


            if (
                getMistakeCountedStatus(
                    item
                )
            ) {

                subjects[
                    subject
                ].counted++;

            }

            else {

                subjects[
                    subject
                ].notCounted++;

            }

        }
    );


    const sorted =
        Object.entries(
            subjects
        ).sort(
            (a, b) =>
                b[1].total -
                a[1].total
        );


    container.innerHTML =

        sorted.map(
            (
                [
                    subject,
                    value
                ]
            ) => {

                const percentage =

                    value.total > 0

                        ?

                        Math.round(
                            (
                                value.counted /
                                value.total
                            ) *
                            100
                        )

                        :

                        0;


                return `

                    <div
                        class="
                            subject-breakdown-card
                        "
                    >


                        <div
                            class="
                                subject-breakdown-top
                            "
                        >


                            <div
                                class="
                                    subject-breakdown-name
                                "
                            >

                                <i
                                    class="
                                        fa-solid
                                        fa-triangle-exclamation
                                    "
                                ></i>


                                <span>
                                    ${subject}
                                </span>

                            </div>


                            <strong>
                                ${value.total}
                            </strong>


                        </div>


                        <div
                            class="
                                subject-breakdown-bar
                            "
                        >

                            <div
                                class="
                                    subject-breakdown-progress
                                "
                                style="
                                    width:${percentage}%;
                                "
                            ></div>

                        </div>
                    </div>

                `;

            }
        ).join("");

}