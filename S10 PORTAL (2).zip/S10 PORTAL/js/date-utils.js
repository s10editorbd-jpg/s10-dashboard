// ====================================
// S10 PORTAL - DATE UTILITIES
// ====================================

// ============================================================
// IMPORTANT DATE RULE
// ============================================================
// S10 mistake dates are CALENDAR dates.
// We must never let a timezone conversion move an entry across
// a month boundary.
//
// Examples:
//   2026-09-30              -> September 30
//   2026-10-01              -> October 1
//   2026-09-30T18:00:00Z   -> October 1 in UTC+06 / UTC+05:30
//
// The last example is important because Google Apps Script can
// serialize a Sheet Date object into an ISO UTC timestamp.
// Reading only the first 10 characters would incorrectly turn
// a local October 1 date into September 30.


// ==============================
// SAFE DATE PARTS
// ==============================

function getMistakeDateParts(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return null;
    }


    // ==============================
    // JavaScript Date object
    // ==============================

    if (value instanceof Date) {

        if (isNaN(value.getTime())) {
            return null;
        }

        return {
            year: value.getFullYear(),
            month: value.getMonth(),
            day: value.getDate()
        };
    }


    // ==============================
    // Google Sheets / Excel serial
    // ==============================

    if (
        typeof value === "number" &&
        Number.isFinite(value)
    ) {

        const utcDate = new Date(
            Date.UTC(1899, 11, 30) +
            Math.round(value * 86400000)
        );

        if (isNaN(utcDate.getTime())) {
            return null;
        }

        return {
            year: utcDate.getUTCFullYear(),
            month: utcDate.getUTCMonth(),
            day: utcDate.getUTCDate()
        };
    }


    const raw = String(value).trim();


    if (!raw) {
        return null;
    }


    // ==============================
    // Numeric serial returned as text
    // ==============================

    if (/^\d+(\.\d+)?$/.test(raw)) {

        const numericValue = Number(raw);

        if (Number.isFinite(numericValue)) {

            const utcDate = new Date(
                Date.UTC(1899, 11, 30) +
                Math.round(numericValue * 86400000)
            );

            if (!isNaN(utcDate.getTime())) {

                return {
                    year: utcDate.getUTCFullYear(),
                    month: utcDate.getUTCMonth(),
                    day: utcDate.getUTCDate()
                };
            }
        }
    }


    // ==============================
    // ISO date-only: YYYY-MM-DD
    // ==============================
    // IMPORTANT:
    // Date-only ISO strings must be read directly from their
    // calendar components. new Date("YYYY-MM-DD") is UTC-based.

    let match = raw.match(
        /^(\d{4})-(\d{1,2})-(\d{1,2})$/
    );

    if (match) {

        const year = Number(match[1]);
        const month = Number(match[2]) - 1;
        const day = Number(match[3]);

        return validateMistakeDateParts(
            year,
            month,
            day
        );
    }


    // ==============================
    // ISO timestamp
    // ==============================
    // IMPORTANT:
    // If Apps Script serialized a Sheet Date into UTC, the UTC
    // date can be one day earlier than the Sheet's local date.
    // In this case we MUST parse the full timestamp and use the
    // browser's local calendar date instead of taking raw.slice(0,10).

    if (
        /^\d{4}-\d{1,2}-\d{1,2}T/i.test(raw)
    ) {

        const parsedTimestamp = new Date(raw);

        if (!isNaN(parsedTimestamp.getTime())) {

            return {
                year: parsedTimestamp.getFullYear(),
                month: parsedTimestamp.getMonth(),
                day: parsedTimestamp.getDate()
            };
        }
    }


    // ==============================
    // Slash / hyphen date
    // ==============================
    // Portal / Sheet convention:
    //   MM/DD/YYYY
    // If first > 12, treat it as DD/MM/YYYY.

    match = raw.match(
        /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})/
    );

    if (match) {

        const first = Number(match[1]);
        const second = Number(match[2]);
        const year = Number(match[3]);

        let month;
        let day;

        if (
            first > 12 &&
            second <= 12
        ) {
            // DD/MM/YYYY
            day = first;
            month = second - 1;
        } else {
            // MM/DD/YYYY
            month = first - 1;
            day = second;
        }

        return validateMistakeDateParts(
            year,
            month,
            day
        );
    }


    // ==============================
    // Final fallback
    // ==============================

    const parsed = new Date(raw);


    if (isNaN(parsed.getTime())) {
        return null;
    }


    return {
        year: parsed.getFullYear(),
        month: parsed.getMonth(),
        day: parsed.getDate()
    };
}


// ==============================
// DATE VALIDATION
// ==============================

function validateMistakeDateParts(
    year,
    month,
    day
) {

    if (
        !Number.isInteger(year) ||
        !Number.isInteger(month) ||
        !Number.isInteger(day) ||
        month < 0 ||
        month > 11 ||
        day < 1 ||
        day > 31
    ) {
        return null;
    }


    const check = new Date(
        year,
        month,
        day
    );


    if (
        check.getFullYear() !== year ||
        check.getMonth() !== month ||
        check.getDate() !== day
    ) {
        return null;
    }


    return {
        year,
        month,
        day
    };
}


// ==============================
// STANDARD DATE OBJECT
// ==============================

function parseMistakeSummaryDate(value) {

    const parts = getMistakeDateParts(value);


    if (!parts) {
        return null;
    }


    return new Date(
        parts.year,
        parts.month,
        parts.day
    );
}


// ==============================
// GENERAL DATE PARSER
// ==============================
// All portal date-based features now use the same safe parser.

function parseDate(value) {
    return parseMistakeSummaryDate(value);
}
