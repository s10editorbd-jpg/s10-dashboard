// ====================================
// S10 PORTAL - DATA + REFRESH
// ====================================

// ==============================
// WAIT FOR DATA
// ==============================

function waitForDataAndRender(name) {

    if (!dataReady) {

        setTimeout(() => {

            waitForDataAndRender(name);

        }, 300);

        return;
    }

    renderMistakes(name);
}


// ==============================
// DATE + TIME
// ==============================

function showDateTime() {

    const now = new Date();

    const time =
        now.getHours().toString().padStart(2, "0") +
        ":" +
        now.getMinutes().toString().padStart(2, "0") +
        ":" +
        now.getSeconds().toString().padStart(2, "0");

    const date =
        now.getDate().toString().padStart(2, "0") +
        "/" +
        (now.getMonth() + 1)
            .toString()
            .padStart(2, "0") +
        "/" +
        now.getFullYear();

    const timeBox =
        document.getElementById("currentTime");

    const dateBox =
        document.getElementById("currentDate");

    if (timeBox) {
        timeBox.innerHTML = time;
    }

    if (dateBox) {
        dateBox.innerHTML = date;
    }
}


setInterval(showDateTime, 1000);

showDateTime();




function loadData() {

    Promise.all([

        fetch(
            BASE_URL + "?type=employee"
        ).then(r => r.json()),

        fetch(
            BASE_URL + "?type=links"
        ).then(r => r.json()),

        fetch(
            BASE_URL + "?type=mistake"
        ).then(r => r.json()),

        fetch(
            BASE_URL + "?type=report"
        ).then(r => r.json())

    ])

    .then(
        ([
            employeeData,
            linksData,
            mistakeData,
            reportData
        ]) => {

            employees =
                employeeData || [];

            filteredEmployees =
                employeeData || [];

            allLinks =
                linksData || [];

            allData =
                Array.isArray(mistakeData)
                    ? mistakeData
                    : [];

            Report =
                Array.isArray(reportData)
                    ? reportData
                    : [];

            dataReady = true;


            // ==============================
            // REPORT MONTH FILTER
            // ==============================

            const monthFilter =
                document.getElementById(
                    "monthFilter"
                );

            if (
                monthFilter &&
                monthFilter.options.length <= 1
            ) {

                loadMonthFilter();

            }


            // ==============================
            // CS FILTERS
            // ==============================

            loadCSNameFilter();

            loadOverviewCSFilter();


            // ==============================
            // OVERVIEW YEAR + MONTH
            // ==============================

            loadOverviewYearFilter();

            loadOverviewMonthFilter();


            // ==============================
            // MISTAKE OVERVIEW
            // ==============================

            renderMistakeOverview();


            // ==============================
            // FIRST LOAD
            // ==============================

            if (firstLoad) {

                renderLinks(
                    "BO",
                    "boLinks"
                );

                renderLinks(
                    "Website Link",
                    "wbLinks"
                );

                renderLinks(
                    "Chat Link",
                    "ctLinks"
                );

                renderLinks(
                    "Deposit PLY",
                    "depositPlyLinks"
                );

                renderLinks(
                    "Deposit Sheet",
                    "depositSheetLinks"
                );

                renderLinks(
                    "SOP",
                    "sopLinks"
                );

                renderLinks(
                    "Sports BO",
                    "sportsBoLinks"
                );

                renderLinks(
                    "Sports",
                    "sportsGameLinks"
                );

                renderLinks(
                    "Other",
                    "otherLinks"
                );


                if (employees.length > 0) {

                    showEmployeeByObject(
                        employees[0]
                    );

                }

                firstLoad = false;
            }


            // ==============================
            // CURRENT EMPLOYEE MISTAKES
            // ==============================

            const empName =
                document.getElementById(
                    "empName"
                )?.innerText;

            if (
                empName &&
                empName !== "Select Employee"
            ) {

                renderMistakes(empName);

            }


            // ==============================
            // REPORT PAGE
            // ==============================

            const reportPage =
                document.getElementById(
                    "reportPage"
                );

            if (
                reportPage &&
                reportPage.style.display !== "none"
            ) {

                renderAllMistakes();

            }


            // ==============================
            // PERFORMANCE SUMMARY
            // ==============================

            renderMistakePerformanceSummary();

        }
    )

    .catch(error => {

        console.error(
            "Data Load Error:",
            error
        );

    });
}


// ==============================
// MANUAL REFRESH
// ==============================

function manualRefresh() {

    loadData();

}


// ==============================
