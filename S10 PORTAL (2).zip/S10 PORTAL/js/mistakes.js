// ====================================
// S10 PORTAL - CURRENT EMPLOYEE MISTAKES
// ====================================

// ==============================
// CURRENT EMPLOYEE MISTAKES
// ==============================

function renderMistakes(csName) {

    const container =
        document.getElementById(
            "mistakeContainer"
        );

    if (!container) return;

    container.innerHTML = "";


    const cleanName =
        String(csName || "")
            .trim()
            .toLowerCase();


    if (!cleanName) {

        container.innerHTML = `
            <p class="no-data">
                No employee selected
            </p>
        `;

        return;
    }


    const runningMonth =
        getRunningMonth();


    container.innerHTML = `

        <div class="mistake-header">

            <div>
                <h2>
                    Showing mistakes for current month
                </h2>
            </div>

            <div class="month-badge">
                📅 ${runningMonth}
            </div>

        </div>

    `;


    const mistakes =
        Report.filter(item => {

            const itemName =
                String(
                    item["CS Name"] || ""
                )
                .trim()
                .toLowerCase();


            const date =
                parseDate(
                    item["Date"]
                );


            if (!date) return false;


            const itemMonth =
                date.toLocaleString(
                    "default",
                    {
                        month: "long",
                        year: "numeric"
                    }
                );


            return (
                itemName === cleanName &&
                itemMonth === runningMonth
            );

        });


    if (mistakes.length === 0) {

        container.innerHTML += `

            <p class="no-data">

                No mistakes found for
                ${runningMonth}

            </p>

        `;

        return;

    }


    const badgeColor = {

        "Wrong Information":
            "wrong-information",

        "Not Follow SOP":
            "not-follow-sop",

        "Late Reply":
            "late-reply",

        "No Reply":
            "no-reply",

        "Angry With Player":
            "angry-player",

        "Non Professional":
            "non-professional",

        "No solution":
            "no-solution",

        "No explanation":
            "no-explanation",

        "Verbal warning":
            "verbal-warning",

        "Warning letter":
            "warning-letter"

    };


    container.innerHTML +=

        mistakes.map(
            (item, index) => {

                const date =
                    parseDate(
                        item["Date"]
                    );


                const colorClass =
                    badgeColor[
                        item["Subject"]
                    ] || "default";


                return `

                    <div
                        class="
                            mistake-card
                            ${colorClass}
                        "
                    >

                        <div class="card-top">

                            <span
                                class="
                                    subject
                                    ${colorClass}
                                "
                            >
                                ${item["Subject"] || "-"}
                            </span>


                            <div
                                style="
                                    display:flex;
                                    align-items:center;
                                    gap:8px;
                                "
                            >

                                <span
                                    class="count-badge"
                                >
                                    ${mistakes.length}
                                </span>


                                <span
                                    class="count-badge"
                                >
                                    #${index + 1}
                                </span>


                                <span
                                    class="
                                        date
                                        ${colorClass}
                                    "
                                >
                                    📅 ${
                                        date
                                            ? date.toLocaleDateString(
                                                "en-GB"
                                            )
                                            : "-"
                                    }
                                </span>

                            </div>

                        </div>
<hr>
<p class="remarks">
    <strong>REMARKS:</strong>
    <br>
    ${item["Detailed Remark"] || "-"}
</p>

<hr>



<p class="Chat link">
    🔗
    ${
        item["Chat link"]
        ?
        `
            <a
                href="${item["Chat link"]}"
                target="_blank"
                rel="noopener noreferrer"
            >
                View Chat
            </a>
        `
        :
        "No Chat Link"
    }
</p>

<p class="link">
    📸
    ${
        item["Screenshot link"]
        ?
        `
            <a
                href="${item["Screenshot link"]}"
                target="_blank"
                rel="noopener noreferrer"
            >
                View Screenshot
            </a>
        `
        :
        "No Screenshot"
    }
</p>


                    </div>

                `;

            }
        ).join("");


    container.innerHTML += `

        <div class="end-list">

            <hr>

            <span>
                ⓘ End of list
            </span>

            <hr>

        </div>

    `;

}


