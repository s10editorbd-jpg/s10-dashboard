// ====================================
// S10 PORTAL - CONFIG + GLOBAL STATE
// ====================================

// ==============================
// LOGIN + CONFIG + GLOBAL
// ==============================

const user = localStorage.getItem("user");
const loginDate = localStorage.getItem("loginDate");
const today = new Date().toLocaleDateString("en-CA");

if (!user || loginDate !== today) {
    localStorage.clear();
    window.location.replace("login.html");
}


const BASE_URL =
"https://script.google.com/macros/s/AKfycbyQhgn5Ll806jilu3Hv-q5k-FRZSu0xqL6j3LQcbaR7bz7DRCXsDfSVCN9Oevle2Gzx/exec";


let employees = [];
let filteredEmployees = [];
let allData = [];
let Report = [];
let allLinks = [];

let dataReady = false;
let firstLoad = true;

let mistakeOverviewChart = null;


