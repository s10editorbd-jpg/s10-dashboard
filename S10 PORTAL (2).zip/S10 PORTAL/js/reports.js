// ====================================
// S10 PORTAL - MISTAKE REPORTS + PAGINATION
// ====================================

// ==============================
// ALL MISTAKE REPORT
// ==============================

let mistakesPerPage = 10;

let currentMistakePage =
    Number(
        localStorage.getItem(
            "mistakePage"
        )
    ) || 1;

let allMistakeReports = [];


// ==============================
// MONTH FILTER
// ==============================

function loadMonthFilter() {

    const select =
        document.getElementById(
            "monthFilter"
        );

    if (!select) return;


    const currentValue =
        select.value;


    let months = [

        ...new Set(

            allData
                .map(item => {

                    const date =
                        parseDate(
                            item["Date"]
                        );

                    if (!date) return null;


                    return date.toLocaleString(
                        "en-GB",
                        {
                            month: "long",
                            year: "numeric"
                        }
                    );

                })
                .filter(Boolean)

        )

    ];


    months.sort(
        (a, b) =>
            new Date(b) -
            new Date(a)
    );


    select.innerHTML = `

        <option value="all">
            All Months 2026
        </option>

    `;


    months.forEach(month => {

        select.innerHTML += `

            <option value="${month}">
                ${month}
            </option>

        `;

    });


    if (currentValue) {

        select.value =
            currentValue;

    }

}


// ==============================
// CS NAME FILTER
// ==============================

function loadCSNameFilter() {

    const select =
        document.getElementById(
            "csNameFilter"
        );

    if (!select) return;


    const currentValue =
        select.value;


    const names = [

        ...new Set(

            allData
                .map(item =>
                    String(
                        item["CS Name"] || ""
                    ).trim()
                )
                .filter(
                    name => name !== ""
                )

        )

    ].sort(
        (a, b) =>
            a.localeCompare(b)
    );


    select.innerHTML = `

        <option value="all">
            All CS
        </option>

    `;


    names.forEach(name => {

        const option =
            document.createElement(
                "option"
            );

        option.value = name;

        option.textContent = name;

        select.appendChild(
            option
        );

    });


    if (
        currentValue &&
        names.includes(currentValue)
    ) {

        select.value =
            currentValue;

    }

}


// ==============================
// ALL MISTAKES
// ==============================

function renderAllMistakes(
    page = currentMistakePage
) {

    const container =
        document.getElementById(
            "reportMistakeContainer"
        );

    if (!container) return;


    let mistakes =
        [...allData];


    const selectedMonth =
        document.getElementById(
            "monthFilter"
        )?.value || "all";


    const selectedName =
        document.getElementById(
            "csNameFilter"
        )?.value || "all";


    if (
        selectedMonth !== "all"
    ) {

        mistakes =
            mistakes.filter(item => {

                const date =
                    parseDate(
                        item["Date"]
                    );

                if (!date) return false;


                const monthYear =
                    date.toLocaleString(
                        "en-GB",
                        {
                            month: "long",
                            year: "numeric"
                        }
                    );


                return (
                    monthYear ===
                    selectedMonth
                );

            });

    }


    if (
        selectedName !== "all"
    ) {

        mistakes =
            mistakes.filter(item => {

                return (
                    String(
                        item["CS Name"] || ""
                    )
                    .trim()
                    .toLowerCase()

                    ===

                    selectedName
                        .trim()
                        .toLowerCase()
                );

            });

    }


    const trueCount =
        mistakes.filter(item =>
            getMistakeCountedStatus(
                item
            )
        ).length;


    const notCounted =
        mistakes.length -
        trueCount;


    mistakes.sort((a, b) => {

        const dateA =
            parseDate(
                a["Date"]
            ) || new Date(0);

        const dateB =
            parseDate(
                b["Date"]
            ) || new Date(0);


        if (
            dateB - dateA !== 0
        ) {

            return (
                dateB - dateA
            );

        }


        return (
            Number(b.Row || 0) -
            Number(a.Row || 0)
        );

    });


    allMistakeReports =
        mistakes;


    const totalPages =
        Math.ceil(
            allMistakeReports.length /
            mistakesPerPage
        );


    if (totalPages === 0) {

        page = 1;

    } else {

        if (page < 1) {
            page = 1;
        }

        if (page > totalPages) {
            page = totalPages;
        }

    }


    currentMistakePage =
        page;


    localStorage.setItem(
        "mistakePage",
        currentMistakePage
    );


    const start =
        (
            currentMistakePage - 1
        ) * mistakesPerPage;


    const end =
        start +
        mistakesPerPage;


    mistakes =
        mistakes.slice(
            start,
            end
        );


    container.innerHTML = `

        <div class="mistake-header">

            <div>

                <h2>
                    All Mistakes Reports
                </h2>

            </div>


            <div
                style="
                    display:flex;
                    gap:10px;
                    align-items:center;
                "
            >

                <div class="count-badge">

                    📊
                    ${allMistakeReports.length}
                    Reports

                </div>
</div>

        </div>

    `;


    container.innerHTML +=
        renderMistakePagination();


    if (!mistakes.length) {

        container.innerHTML += `

            <p class="no-data">
                No reports found.
            </p>

        `;

        return;

    }


    const badgeColor = {

        "Wrong Information":
            "wrong-information",

        "Not Follow SOP":
            "not-follow-sop",

        "Late Reply":
            "late-reply",

        "No Reply":
            "no-reply",

        "Angry With Player":
            "angry-player",

        "Non Professional":
            "non-professional",

        "No solution":
            "no-solution",

        "No explanation":
            "no-explanation",

        "Verbal warning":
            "verbal-warning",

        "Warning letter":
            "warning-letter"

    };


    const html =
        mistakes.map(item => {

            const date =
                parseDate(
                    item["Date"]
                );


            const colorClass =
                badgeColor[
                    item["Subject"]
                ] || "default";


            const reported =
                String(
                    item[
                        "Reported in file"
                    ] || ""
                )
                .trim()
                .toUpperCase();


            const reportClass =
                reported === "TRUE"
                    ? "reported-true"
                    : "reported-false";


            return `

                <div
                    class="
                        mistake-card
                        ${colorClass}
                        ${reportClass}
                    "
                >

                    <p class="cs-name">

                        👤

                        <strong>
                            ${
                                item[
                                    "CS Name"
                                ] || "-"
                            }
                        </strong>

                    </p>


                    <div class="card-top">

                        <span
                            class="
                                subject
                                ${colorClass}
                            "
                        >
                            ${
                                item[
                                    "Subject"
                                ] || "-"
                            }
                        </span>


                        <span
                            class="
                                date
                                ${colorClass}
                            "
                        >

                            📅

                            ${
                                date
                                    ? date.toLocaleDateString(
                                        "en-GB"
                                    )
                                    : "-"
                            }

                        </span>

                    </div>
<hr>


                    <p class="remarks">

                        <strong>
                            Feedback from (TL/Senior):
                        </strong>

                        <br>

                        ${
                            item[
                                "Feedback from (TL/Senior)"
                            ] || "-"
                        }

                    </p>


                    <hr>


                    <div class="links">

                        ${
                            item["Chat link"]

                            ?

                            `
                                <a
                                    href="${
                                        item[
                                            "Chat link"
                                        ]
                                    }"
                                    target="_blank"
                                    class="chat-link"
                                >
                                    💬 View Chat
                                </a>
                            `

                            :

                            ""
                        }


                        ${
                            item[
                                "Screenshot link"
                            ]

                            ?

                            `
                                <a
                                    href="${
                                        item[
                                            "Screenshot link"
                                        ]
                                    }"
                                    target="_blank"
                                    class="ss-link"
                                >
                                    🖼 View Screenshot
                                </a>
                            `

                            :

                            ""
                        }


                        ${
                            !item["Chat link"] &&
                            !item["Screenshot link"]

                            ?

                            "No Attachment"

                            :

                            ""
                        }

                    </div>

                </div>

            `;

        }).join("");


    container.insertAdjacentHTML(
        "beforeend",
        html
    );


    container.insertAdjacentHTML(
        "beforeend",
        renderMistakePagination()
    );

}


// ==============================
// PAGINATION
// ==============================

function renderMistakePagination() {

    const totalPages =
        Math.ceil(
            allMistakeReports.length /
            mistakesPerPage
        );


    if (totalPages <= 1) {

        return "";

    }


    let html = `

        <div class="pagination">

            <button
                onclick="
                    renderAllMistakes(
                        ${currentMistakePage - 1}
                    )
                "
                ${
                    currentMistakePage === 1
                        ? "disabled"
                        : ""
                }
            >
                ⬅ Prev
            </button>

    `;


    const maxVisible = 7;


    let start =
        Math.max(
            1,
            currentMistakePage - 3
        );


    let end =
        Math.min(
            totalPages,
            currentMistakePage + 3
        );


    if (
        currentMistakePage <= 4
    ) {

        end =
            Math.min(
                totalPages,
                maxVisible
            );

    }


    if (
        currentMistakePage >=
        totalPages - 3
    ) {

        start =
            Math.max(
                1,
                totalPages -
                maxVisible +
                1
            );

    }


    if (start > 1) {

        html += `

            <button
                onclick="
                    renderAllMistakes(1)
                "
            >
                1
            </button>

        `;


        if (start > 2) {

            html += `
                <span class="dots">
                    ...
                </span>
            `;

        }

    }


    for (
        let i = start;
        i <= end;
        i++
    ) {

        html += `

            <button
                onclick="
                    renderAllMistakes(${i})
                "
                class="${
                    i === currentMistakePage
                        ? "active-page"
                        : ""
                }"
            >
                ${i}
            </button>

        `;

    }


    if (
        end < totalPages
    ) {

        if (
            end <
            totalPages - 1
        ) {

            html += `

                <span class="dots">
                    ...
                </span>

            `;

        }


        html += `

            <button
                onclick="
                    renderAllMistakes(
                        ${totalPages}
                    )
                "
            >
                ${totalPages}
            </button>

        `;

    }


    html += `

            <button
                onclick="
                    renderAllMistakes(
                        ${currentMistakePage + 1}
                    )
                "
                ${
                    currentMistakePage ===
                    totalPages
                        ? "disabled"
                        : ""
                }
            >
                Next ➡
            </button>

        </div>

    `;


    return html;

}


// ==============================
