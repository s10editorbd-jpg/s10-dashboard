
// ====================================
// S10 PORTAL - HOME + PERFORMANCE SUMMARY
// ====================================


// ============================================================
// HOME MISTAKE REPORT
// ============================================================

function renderHomeMistakeReports() {

    const container = document.getElementById("homeMistakeSubjects");
    const totalElement = document.getElementById("homeMistakeTotal");
    const monthElement = document.getElementById("homeMistakeMonth");

    if (!container) return;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const monthName = now.toLocaleString("en-US", {
        month: "long",
        year: "numeric"
    });

    if (monthElement) {
        monthElement.textContent = `📅 ${monthName}`;
    }

    const currentMonthMistakes = Array.isArray(allData)
        ? allData.filter(item => {

            const date = parseDate(item["Date"]);

            if (!date) return false;

            return (
                date.getMonth() === currentMonth &&
                date.getFullYear() === currentYear
            );

        })
        : [];

    if (totalElement) {
        totalElement.textContent = currentMonthMistakes.length;
    }

    const subjectCounts = {};

    currentMonthMistakes.forEach(item => {

        const subject = String(item["Subject"] || "Other").trim();

        if (!subject) return;

        if (!subjectCounts[subject]) {
            subjectCounts[subject] = {
                total: 0
            };
        }

        subjectCounts[subject].total++;

    });

    const subjects = Object.entries(subjectCounts);

    if (!subjects.length) {

        container.innerHTML = `
            <div class="home-mistake-empty">

                <i class="fa-solid fa-circle-check"></i>

                <h3>No mistakes found</h3>

                <p>
                    No mistake reports for
                    <strong>${monthName}</strong>
                </p>

            </div>
        `;

        return;
    }

    subjects.sort((a, b) => b[1].total - a[1].total);

    const subjectClass = {

        "Wrong Information": "wrong-information",
        "Not Follow SOP": "not-follow-sop",
        "Late Reply": "late-reply",
        "No Reply": "no-reply",
        "Angry With Player": "angry-player",
        "Non Professional": "non-professional",
        "No solution": "no-solution",
        "No explanation": "no-explanation",
        "Verbal warning": "verbal-warning",
        "Warning letter": "warning-letter"

    };

    container.innerHTML = subjects.map(([subject, data]) => {

        const colorClass = subjectClass[subject] || "default";

        return `
            <div class="home-mistake-card ${colorClass}">

                <div class="home-mistake-card-top">

                    <div class="home-mistake-icon">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>

                    <div class="home-mistake-count">
                        ${data.total}
                    </div>

                </div>

                <div class="home-mistake-subject">
                    ${subject}
                </div>

                <div class="home-mistake-label">
                    Reports
                </div>

            </div>
        `;

    }).join("");

}


// ============================================================
// HOME CLOCK
// ============================================================

function updateHomeClock() {

    const now = new Date();

    const timeElement = document.getElementById("homeTime");
    const dateElement = document.getElementById("homeDate");

    if (timeElement) {

        timeElement.textContent =
            now.toLocaleTimeString("en-GB");

    }

    if (dateElement) {

        dateElement.textContent =
            now.toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "short",
                year: "numeric"
            });

    }

}

updateHomeClock();

setInterval(updateHomeClock, 1000);


// ============================================================
// HOME STATS
// ============================================================

function updateHomeStats() {

    const totalCS = document.getElementById("homeTotalCS");

    if (totalCS && typeof employees !== "undefined") {

        totalCS.textContent =
            Array.isArray(employees)
                ? employees.length
                : "-";

    }

    const mistakes = document.getElementById("homeMistakes");

    if (mistakes && typeof allData !== "undefined") {

        const now = new Date();

        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();

        const currentMonthMistakes = Array.isArray(allData)
            ? allData.filter(item => {

                const date =
                    typeof parseDate === "function"
                        ? parseDate(item["Date"])
                        : null;

                if (!date) return false;

                return (
                    date.getMonth() === currentMonth &&
                    date.getFullYear() === currentYear
                );

            })
            : [];

        mistakes.textContent = currentMonthMistakes.length;

    }

    if (
        typeof allData !== "undefined" &&
        Array.isArray(allData)
    ) {

        if (typeof renderHomeMistakeReports === "function") {
            renderHomeMistakeReports();
        }

    }

}

setTimeout(updateHomeStats, 1500);

setInterval(updateHomeStats, 5000);


// ============================================================
// MISTAKE PERFORMANCE SUMMARY
// ============================================================

const mistakeMonthNames = [

    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"

];


// ==============================
// SUBJECT
// ==============================

function getMistakeSubject(item) {

    if (!item) return "Unknown";

    return String(

        item.Subject ||
        item.subject ||
        item.Mistake ||
        item.mistake ||
        item["Mistake Type"] ||
        item["Subject"] ||
        "Unknown"

    ).trim();

}


// ==============================
// COUNTED STATUS
// ==============================

function getMistakeCountedStatus(item) {

    if (!item) return false;

    const value = String(

        item["Reported in file"] ??
        item.Reported ??
        item.reported ??
        item.Counted ??
        item.counted ??
        item.Status ??
        item.status ??
        ""

    ).trim().toLowerCase();

    return [
        "true",
        "yes",
        "counted",
        "reported",
        "1"
    ].includes(value);

}


// ==============================
// RATING
// ==============================

function getMistakeRating(count) {

    if (count === 0) {

        return {
            text: "No Mistakes",
            icon: "fa-circle-check",
            className: "excellent"
        };

    }

    if (count <= 20) {

        return {
            text: "Very Good",
            icon: "fa-star",
            className: "very-good"
        };

    }

    if (count <= 40) {

        return {
            text: "Good",
            icon: "fa-thumbs-up",
            className: "good"
        };

    }

    if (count <= 60) {

        return {
            text: "Average",
            icon: "fa-face-meh",
            className: "average"
        };

    }

    if (count <= 80) {

        return {
            text: "Poor",
            icon: "fa-face-frown",
            className: "poor"
        };

    }

    return {
        text: "Very Poor",
        icon: "fa-triangle-exclamation",
        className: "very-poor"
    };

}


// ==============================
// SUMMARY DATA
// ==============================

function getMistakeSummaryData() {

    let data = [];

    if (Array.isArray(allData)) {

        data = allData;

    } else if (Array.isArray(Report)) {

        data = Report;

    }

    return data;

}


// ==============================
// PERFORMANCE SUMMARY
// ==============================

function renderMistakePerformanceSummary() {

    const grid = document.getElementById("mistakeMonthlyGrid");

    if (!grid) return;

    const yearFilter = document.getElementById("mistakeYearFilter");
    const monthFilter = document.getElementById("mistakeMonthFilter");

    const selectedYear = Number(yearFilter?.value || 2026);
    const selectedMonth = monthFilter?.value ?? "all";

    const data = getMistakeSummaryData();

    const monthlyData = mistakeMonthNames.map((month, index) => ({

        month,
        monthIndex: index,
        total: 0,
        counted: 0,
        notCounted: 0,
        subjects: {}

    }));

    data.forEach(item => {

        const date = parseMistakeSummaryDate(
            item.Date ?? item.date ?? item["Date"]
        );

        if (!date) return;

        if (date.getFullYear() !== selectedYear) return;

        const month = date.getMonth();

        if (
            selectedMonth !== "all" &&
            month !== Number(selectedMonth)
        ) return;

        const monthData = monthlyData[month];

        monthData.total++;

        const isCounted = getMistakeCountedStatus(item);

        if (isCounted) {
            monthData.counted++;
        } else {
            monthData.notCounted++;
        }

        const subject = getMistakeSubject(item);

        monthData.subjects[subject] =
            (monthData.subjects[subject] || 0) + 1;

    });

    let displayMonths;

    if (selectedMonth === "all") {

        displayMonths = monthlyData;

    } else {

        displayMonths = [
            monthlyData[Number(selectedMonth)]
        ];

    }

    grid.innerHTML = displayMonths.map(month => {

        const rating = getMistakeRating(month.total);

        return `
            <div class="
                month-performance-card
                ${rating.className}
                ${month.total === 0 ? "empty" : ""}
            ">

                <div class="month-performance-top">

                    <span class="month-name">
                        ${month.month}
                    </span>

                    <span class="month-number">
                        ${String(month.monthIndex + 1).padStart(2, "0")}
                    </span>

                </div>

                <div class="month-mistake-count">
                    ${month.total}
                </div>

                <div class="month-mistake-label">
                    Total Mistakes
                </div>

                <div class="month-rating">

                    <i class="fa-solid ${rating.icon}"></i>

                    ${rating.text}

                </div>

            </div>
        `;

    }).join("");

    updateMistakeSummaryStats(
        monthlyData,
        selectedMonth
    );

    const status = document.getElementById("monthlySummaryStatus");

    if (status) {

        status.textContent =
            selectedMonth === "all"
                ? `${selectedYear} • All Months`
                : `${mistakeMonthNames[Number(selectedMonth)]} ${selectedYear}`;

    }

}


// ==============================
// SUMMARY STATS
// ==============================

function updateMistakeSummaryStats(monthlyData, selectedMonth) {

    let selectedData;

    if (selectedMonth === "all") {

        selectedData = {

            total: 0,
            counted: 0,
            notCounted: 0,
            subjects: {}

        };

        monthlyData.forEach(month => {

            selectedData.total += month.total;
            selectedData.counted += month.counted;
            selectedData.notCounted += month.notCounted;

            Object.entries(month.subjects).forEach(([subject, count]) => {

                selectedData.subjects[subject] =
                    (selectedData.subjects[subject] || 0) + count;

            });

        });

    } else {

        selectedData = monthlyData[Number(selectedMonth)];

    }

    const total = document.getElementById("summaryTotal");
    const counted = document.getElementById("summaryCounted");
    const notCounted = document.getElementById("summaryNotCounted");

    if (total) {
        total.textContent = selectedData.total;
    }

    if (counted) {
        counted.textContent = selectedData.counted;
    }

    if (notCounted) {
        notCounted.textContent = selectedData.notCounted;
    }

    const rating = document.getElementById("summaryRating");

    if (rating) {

        const result = getMistakeRating(selectedData.total);

        rating.textContent = result.text;

    }

    const activeMonths = monthlyData.filter(
        month => month.total > 0
    );

    const worstMonth = document.getElementById("worstMonth");
    const bestMonth = document.getElementById("bestMonth");

    if (activeMonths.length) {

        const worst = [...activeMonths].sort(
            (a, b) => b.total - a.total
        )[0];

        const best = [...activeMonths].sort(
            (a, b) => a.total - b.total
        )[0];

        if (worstMonth) {
            worstMonth.textContent =
                `${worst.month} (${worst.total})`;
        }

        if (bestMonth) {
            bestMonth.textContent =
                `${best.month} (${best.total})`;
        }

    } else {

        if (worstMonth) {
            worstMonth.textContent = "-";
        }

        if (bestMonth) {
            bestMonth.textContent = "-";
        }

    }

    const topMistake = document.getElementById("topMistake");

    const subjects = Object.entries(
        selectedData.subjects || {}
    );

    if (subjects.length) {

        subjects.sort((a, b) => b[1] - a[1]);

        if (topMistake) {
            topMistake.textContent =
                `${subjects[0][0]} (${subjects[0][1]})`;
        }

    } else {

        if (topMistake) {
            topMistake.textContent = "-";
        }

    }

}


// ==============================
// PERFORMANCE SUMMARY INIT
// ==============================

function initMistakePerformanceSummary() {

    const yearFilter = document.getElementById("mistakeYearFilter");
    const monthFilter = document.getElementById("mistakeMonthFilter");

    if (yearFilter) {
        yearFilter.onchange = renderMistakePerformanceSummary;
    }

    if (monthFilter) {
        monthFilter.onchange = renderMistakePerformanceSummary;
    }

    renderMistakePerformanceSummary();

}
