// ====================================
// S10 PORTAL - EMPLOYEE + BRAND
// ====================================

// EMPLOYEE LIST
// ==============================

function renderEmployeeList(list) {

    const container =
        document.getElementById(
            "employeeList"
        );

    if (!container) return;

    container.innerHTML = "";

    list.forEach(emp => {

        const card =
            document.createElement("div");

        card.className = "employee";

        card.innerHTML = `
            <h4>
                ${emp["CS Name"] || "-"}
            </h4>

            <p>
                ${emp["STAFF Position"] || "-"}
            </p>
        `;

        card.onclick = () => {

            showEmployeeByObject(emp);

            const search =
                document.getElementById(
                    "search"
                );

            if (search) {

                search.value =
                    emp["CS Name"] || "";

            }

            container.innerHTML = "";

        };

        container.appendChild(card);

    });
}


// ==============================
// EMPLOYEE SEARCH
// ==============================



// ==============================
// SHOW EMPLOYEE
// ==============================

function showEmployeeByObject(
    emp,
    showReport = true
) {

    if (!emp) return;


    const setText =
        (id, value) => {

            const el =
                document.getElementById(id);

            if (el) {

                el.innerText =
                    value || "-";

            }

        };


    setText(
        "empName",
        emp["CS Name"]
    );

    setText(
        "empPosition",
        emp["STAFF Position"]
    );

    setText(
        "psd",
        emp["PSD ID"]
    );

    setText(
        "office",
        emp["Office Location"] ||
        emp["Office Locaton"] ||
        "-"
    );

    setText(
        "teamid",
        emp["STAFF MS Team ID"]
    );

    setText(
        "agent",
        emp["ICX Agent"]
    );

    setText(
        "group",
        emp["Group"]
    );

    setText(
        "mistake",
        emp["Mistake"]
    );


    const search =
        document.getElementById(
            "search"
        );

    if (search) {

        search.value =
            emp["CS Name"] || "";

    }


    const list =
        document.getElementById(
            "employeeList"
        );

    if (list) {

        list.innerHTML = "";

    }


    const avatar =
        document.getElementById(
            "avatar"
        );

    if (avatar) {

        const name =
            String(
                emp["CS Name"] || ""
            ).trim();

        avatar.innerText =
            name
                ? name.charAt(0).toUpperCase()
                : "?";

    }


    // ==============================
    // BRANDS
    // ==============================

    setBrand(
        "superbo",
        emp["Super BO"]
    );

    setBrand(
        "dp",
        emp["DP"]
    );

    setBrand(
        "kv",
        emp["KV"]
    );

    setBrand(
        "hb",
        emp["HB"]
    );

    setBrand(
        "jb",
        emp["JB"]
    );

    setBrand(
        "jway",
        emp["JWAY"]
    );

    setBrand(
        "sb",
        emp["SB"]
    );

    setBrand(
        "slb",
        emp["SLB"]
    );

    setBrand(
        "bjdb",
        emp["BJDB"]
    );

    setBrand(
        "bn",
        emp["BN"]
    );

    setBrand(
        "bdvegas",
        emp["BDVegas"]
    );

    setBrand(
        "cpc88",
        emp["CPC88"]
    );

    setBrand(
        "deshi777",
        emp["Deshi777"]
    );


    if (showReport) {

        renderMistakes(
            emp["CS Name"]
        );

    }

}


// ==============================
// BRAND
// ==============================

function setBrand(id, value) {

    const box =
        document.getElementById(id);

    if (!box) return;

    const title =
        box.dataset?.title || "";

    if (
        value &&
        String(value).trim() !== ""
    ) {

        box.className =
            "brand-card active-brand";

        box.innerHTML = `
            <div class="brand-name">
                ${title}
            </div>

            <div class="brand-value">
                ${value}
            </div>
        `;

    } else {

        box.className =
            "brand-card inactive-brand";

        box.innerHTML = `
            <div class="brand-name">
                ${title}
            </div>

            <div class="brand-value">
                No Access
            </div>
        `;

    }

}


// ==============================
