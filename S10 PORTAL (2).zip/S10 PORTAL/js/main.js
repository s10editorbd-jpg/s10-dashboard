// ====================================
// S10 PORTAL - MAIN INITIALIZATION
// ====================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        loadData();

        const searchBox =
            document.getElementById("search");

        if (searchBox) {
            searchBox.addEventListener(
                "keyup",
                function () {

                    const txt =
                        this.value.trim().toLowerCase();

                    const list =
                        document.getElementById("employeeList");

                    if (!txt) {
                        if (list) list.innerHTML = "";
                        return;
                    }

                    const filtered = employees.filter(
                        emp => String(emp["CS Name"] || "")
                            .toLowerCase()
                            .includes(txt)
                    );

                    renderEmployeeList(filtered);
                }
            );
        }

        const monthFilter =
            document.getElementById("monthFilter");

        if (monthFilter) {
            monthFilter.onchange = () => {
                currentMistakePage = 1;
                renderAllMistakes(1);
            };
        }

        const csNameFilter =
            document.getElementById("csNameFilter");

        if (csNameFilter) {
            csNameFilter.onchange = () => {
                currentMistakePage = 1;
                renderAllMistakes(1);
            };
        }

        initMistakePerformanceSummary();

        setTimeout(
            initMistakeOverview,
            1000
        );
    }
);


window.addEventListener(
    "load",
    () => {

        const reportPage =
            document.getElementById("reportPage");

        if (
            reportPage &&
            reportPage.style.display !== "none"
        ) {
            loadMonthFilter();
            renderAllMistakes();
        }

    }
);
